package es.officetattoo.www.clase19recycleviewtarea1movies;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import static es.officetattoo.www.clase19recycleviewtarea1movies.R.id.full_Imagen;

public class FullInfoDetails extends AppCompatActivity {

    private ArrayList<Movie> arrayDePeliculas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_info_details);

        int posision = getIntent().getIntExtra("rowElements" , -1);
        Log.v("**Tag Detail Activyti" , "posision"+ Integer.toString(posision));

        arrayDePeliculas = new ArrayList<Movie>();

        agregarPeliculas();

        Movie miMovie = arrayDePeliculas.get(posision);

        TextView fullTitle = (TextView) findViewById(R.id.full_Titulo);
        TextView fullGenero = (TextView) findViewById(R.id.full_genero);
        TextView fullDescripsion = (TextView) findViewById(R.id.full_descripsion);
        ImageView fullImagen = (ImageView) findViewById(R.id.full_Imagen );



        fullTitle.setText(miMovie.titulo);
        fullGenero.setText(miMovie.genero);
        fullDescripsion.setText(miMovie.descripcion);


        Resources res = getContext().getResources();
        int resID = res.getIdentifier(miMovie.imagen,"mipmap", getContext().getPackageName());
        fullImagen.setImageResource(resID);


    }

    private Context getContext() {
        return this;
    }

    private void agregarPeliculas() {
        arrayDePeliculas.add(new Movie("Aquaman", "CineFicion/Accion","Arthur Curry, también conocido como Aquaman (Jason Momoa), es el líder de un poderoso reino subacuático conocido como la Atlántida....","aquaman"));
        arrayDePeliculas.add(new Movie("Bumblebee","CineFicion/Accion","En su huida en el año 1987, Bumblebee encuentra refugio en una chatarrería de un pequeño pueblo costero de California. Charlie, a punto de cumplir 18 años, y...","bumblebee"));
        arrayDePeliculas.add(new Movie("Pokémon","CineFicion/Accion","Cuando el gran detective privado Harry Goodman desaparece misteriosamente; Tim, su hijo de 21 años, debe averiguar qué sucedió... ","pokemon"));
        arrayDePeliculas.add(new Movie("CapitanMarvel","CineFicion/Accion","La historia sigue a Carol Danvers mientras ella se convierte en uno de los héroes más poderosos del universo cuando la Tierra se encuentre atrapada ....","capitanmarvel"));
        arrayDePeliculas.add(new Movie("El rey leon","CineFicion/Accion","En la sabana africana donde ha nacido el futuro rey. Simba idolatra a su padre, el rey Mufasa, y se toma muy en serio su propio destino real.","elreyleon"));
        arrayDePeliculas.add(new Movie("Aladin","CineFicion/Accion","Mena Massoud interpreta el personaje de Aladdín, un joven pobre a la vez que soñador que, pese a su situación de extrema pobreza, sueña con poder casarse algún día con la princesa Jasmine. ","aladin"));
        arrayDePeliculas.add(new Movie("X-MAN","CineFicion/Accion","La cinta continúa la historia de la patrulla mutante una vez ya han formado el equipo liderado por el Profesor Charles Xavier (James McAvoy). En esta ocasión, deberán enfrentarse a un reto para el que no están nada preparados: ","xman"));

    }

}
