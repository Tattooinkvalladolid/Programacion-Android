package es.officetattoo.www.clase19recycleviewtarea1movies;



import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class AdapterPeliculas extends RecyclerView.Adapter<AdapterPeliculas.MovieViewHolder> {



    private List<Movie> listaPeliculas;
    private Context context;

    private ImageView imageView;
    private String packageName;



    //La declaracion del metodo Movie view Holder
    public class MovieViewHolder extends RecyclerView.ViewHolder {

        public TextView apTitulo;
        public TextView apGenero;
        public TextView apDescripcion;
        public ImageView apImagen;


        //Identificadores de elemontos en el xml
        public MovieViewHolder(View itemView) {
            super(itemView);

            apTitulo = (TextView) itemView.findViewById(R.id.id_Titulo_item);
            apGenero = (TextView) itemView.findViewById(R.id.id_Genero_item);
            apDescripcion = (TextView) itemView.findViewById(R.id.id_Descripcion_item);
            apImagen = (ImageView) itemView.findViewById(R.id.id_Imagen_iteam);




        }
    }

    public AdapterPeliculas(Context context , List<Movie> pelis) {
        this.listaPeliculas = pelis;
        this.context = context;

    }

    //Sobre ecribir metodo viewHolder selecciona que xml otiliza
    @NonNull
    @Override
    public AdapterPeliculas.MovieViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View peliView = inflater.inflate(R.layout.aparencia,parent,false);
        MovieViewHolder movieViewHolder = new MovieViewHolder(peliView);

        return movieViewHolder;

    }

    //Sobre escribir metodo onBindViewHolder
    @Override
    public void onBindViewHolder(@NonNull MovieViewHolder movieViewHolder, final int position) {



        Movie pelicula = this.listaPeliculas.get(position);

        TextView tituloTextView = movieViewHolder.apTitulo;
        tituloTextView.setText(pelicula.titulo);
        TextView generoTextView = movieViewHolder.apGenero;
        generoTextView.setText(pelicula.genero);
        TextView descripsionTextView = movieViewHolder.apDescripcion;
        descripsionTextView.setText(pelicula.descripcion);


        ImageView imageView = movieViewHolder.apImagen;

        Resources res = getContext().getResources();
        int resID = res.getIdentifier(pelicula.imagen,"mipmap", getContext().getPackageName());
        imageView.setImageResource(resID);


       movieViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.v("Adapter", "Row clicked position: " + position);
                showConsoleDetails(position);
            }
        });

    }

        public void showConsoleDetails(int posion){
            Intent i = new Intent(this.context, FullInfoDetails.class);
            i.putExtra("rowElements", posion);
            
            this.context.startActivity(i);
        }



    //Metodo Context
    private Context getContext(){
        return this.context;
    }

    //Metodo que devuelve el tamaño del array
    @Override
    public int getItemCount() {
        return listaPeliculas.size();
    }




}



