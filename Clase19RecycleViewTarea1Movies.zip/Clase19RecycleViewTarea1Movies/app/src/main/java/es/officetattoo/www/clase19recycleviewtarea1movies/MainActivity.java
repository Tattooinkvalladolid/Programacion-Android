package es.officetattoo.www.clase19recycleviewtarea1movies;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<Movie> movies;
    private RecyclerView listaMovies;
    private AdapterPeliculas adapterPeliculas;
    private ImageView imageView;
    private ArrayList<Movie> arrayDePeliculas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listaMovies = (RecyclerView) findViewById(R.id.id_RecycleView_am);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        listaMovies.setLayoutManager(linearLayoutManager);


        inicarAdapter();
    }
    void inicarAdapter(){

        RecyclerView recyclerViewDePeliculas = (RecyclerView) findViewById(R.id.id_RecycleView_am);

        arrayDePeliculas = new ArrayList <Movie>();

        listaArrayDePeliculas();
        //prueba();
        AdapterPeliculas adapter = new AdapterPeliculas(this,arrayDePeliculas);

        recyclerViewDePeliculas.setAdapter(adapter);
        recyclerViewDePeliculas.setLayoutManager(new LinearLayoutManager(this));



    }
    void prueba(){
        arrayDePeliculas.add(new Movie("Aladin", "CineFicion/Accion","Arthur Curry, también conocido como Aquaman (Jason Momoa), es el líder de un poderoso reino subacuático conocido como la Atlántida.","aquaman"));

    }
    void listaArrayDePeliculas() {
        arrayDePeliculas.add(new Movie("Aquaman", "CineFicion/Accion","Arthur Curry, también conocido como Aquaman (Jason Momoa), es el líder de un poderoso reino subacuático conocido como la Atlántida....","aquaman"));
        arrayDePeliculas.add(new Movie("Bumblebee","CineFicion/Accion","En su huida en el año 1987, Bumblebee encuentra refugio en una chatarrería de un pequeño pueblo costero de California. Charlie, a punto de cumplir 18 años, y...","bumblebee"));
        arrayDePeliculas.add(new Movie("Pokémon","CineFicion/Accion","Cuando el gran detective privado Harry Goodman desaparece misteriosamente; Tim, su hijo de 21 años, debe averiguar qué sucedió... ","pokemon"));
        arrayDePeliculas.add(new Movie("CapitanMarvel","CineFicion/Accion","La historia sigue a Carol Danvers mientras ella se convierte en uno de los héroes más poderosos del universo cuando la Tierra se encuentre atrapada ....","capitanmarvel"));
        arrayDePeliculas.add(new Movie("El rey leon","CineFicion/Accion","En la sabana africana donde ha nacido el futuro rey. Simba idolatra a su padre, el rey Mufasa, y se toma muy en serio su propio destino real.","elreyleon"));
        arrayDePeliculas.add(new Movie("Aladin","CineFicion/Accion","Mena Massoud interpreta el personaje de Aladdín, un joven pobre a la vez que soñador que, pese a su situación de extrema pobreza, sueña con poder casarse algún día con la princesa Jasmine. ","aladin"));
        arrayDePeliculas.add(new Movie("X-MAN","CineFicion/Accion","La cinta continúa la historia de la patrulla mutante una vez ya han formado el equipo liderado por el Profesor Charles Xavier (James McAvoy). En esta ocasión, deberán enfrentarse a un reto para el que no están nada preparados: ","xman"));

    }
 }
