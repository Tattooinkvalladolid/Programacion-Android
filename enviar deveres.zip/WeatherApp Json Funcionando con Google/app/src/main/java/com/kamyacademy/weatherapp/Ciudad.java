package com.kamyacademy.weatherapp;

public class Ciudad {
    String nombre;
    String tiempo;

    public Ciudad(String nombre, String tiempo, String temperatura) {
        this.nombre = nombre;
        this.tiempo = tiempo;
        this.temperatura = temperatura;
    }

    String temperatura;
}
