package com.kamyacademy.weatherapp;
import android.app.Activity;
import android.content.res.Resources;
import android.os.AsyncTask;
import org.json.simple.*; // Import this library
import org.json.simple.parser.JSONParser; // Import this library
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import org.json.simple.parser.ParseException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import javax.net.ssl.HttpsURLConnection;
import java.util.ArrayList;

public class WeatherRequestAsyncTask extends AsyncTask {

    public Activity context;
    public String urlString = null;
    private String TAG = getClass().getSimpleName();
    ArrayList<Ciudad> miLista = new ArrayList<Ciudad>();

    // UI Holders
    private String weather =  null;
    private String icono =  null;
    private String temperature =  null;

    // AsyncTask lifecycle methods
    @Override
    protected Object doInBackground(Object[] objects) {
        Log.d(TAG, "doInBackground...");

        try {
            getWeatherJSON();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    protected void onPostExecute(Object o) {
        super.onPostExecute(o);
        Log.d(TAG, "onPostExecute...");
        // Update UI once download is completed
    }

    // HTTP Request
    void getWeatherJSON() throws IOException {

        // Create URL
        URL url = new URL(urlString);

        // Create connection
        HttpURLConnection httpConnection = (HttpURLConnection) url.openConnection();

        InputStream responseBody = null;
        if (httpConnection.getResponseCode() == 200) {
            responseBody = httpConnection.getInputStream();
            InputStreamReader responseBodyReader = new InputStreamReader(responseBody, "UTF-8");

            // Creates a JSON parser *new
            JSONParser jsonParser = new JSONParser();
            try {
                JSONObject jsonObject = (JSONObject)jsonParser.parse(responseBodyReader);

                JSONArray ciudades = (JSONArray) jsonObject.get("ciudades");

                for(Object o: ciudades){
                    JSONObject ciudadJSON = (JSONObject) o;
                    String ciudad = (String) ciudadJSON.get("nombre");
                    String temperatura = (String) ciudadJSON.get("temperatura");
                    String icono = (String) ciudadJSON.get("icono");

                    mensajeDeRevision(ciudad , temperatura , icono);

                    update(ciudad , temperatura , icono);

                }

            } catch (ParseException e) {
                e.printStackTrace();
            }

        } else {
            Log.d(TAG, "HTTP connection failed");
        }

        httpConnection.disconnect();
    }

    private void mensajeDeRevision(String ciudad, String temperatura, String icono) {
        Log.d(TAG, "Comprobando lectura Json \n1++");
        Log.d(TAG, "Ciudad " + ciudad);
        Log.d(TAG, "Temperatura " + temperatura);
        Log.d(TAG, "Icono " + icono);

    }


    private void update(String ciudad, String temperatura, String icono) {

        // use add() method to add elements in the list
        /*miLista.add(ciudad);
        miLista.add(temperatura);
        miLista.add(icono);*/
        miLista.add(new Ciudad(ciudad,temperatura,icono));

        TextView textoTiempo = (TextView) context.findViewById(R.id.tiempoText);
        TextView gradosText = (TextView) context.findViewById(R.id.temperaturaText);
        ImageView iconoText = (ImageView) context.findViewById(R.id.iconoTiempo);

        textoTiempo.setText(ciudad);
        gradosText.setText(temperatura);

        Resources res = context.getResources();

        int resID = res.getIdentifier("luna" , "drawable", context.getPackageName());
        iconoText.setImageResource(resID);

        // let us print all the elements available in list
        for (Ciudad number : miLista) {
            System.out.print("Aqui es el Array ************************");
            System.out.println("Number = " + number);
        }

    }



}
