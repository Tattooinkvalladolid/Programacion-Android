package com.kamyacademy.weatherapp;

import android.app.Activity;
import android.content.res.Resources;
import android.os.AsyncTask;
import android.util.JsonReader;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class WeatherRequestAsyncTask extends AsyncTask {

    public Activity context;
    public String urlString = null;
    private String TAG = getClass().getSimpleName();

    // UI Holders
    private String weather =  null;
    private String icon =  null;
    private String temperature =  null;

    // AsyncTask lifecycle methods
    @Override
    protected Object doInBackground(Object[] objects) {
        Log.d(TAG, "doInBackground...");
        try {
             getWeatherJSON();
        } catch (IOException e) {
            e.printStackTrace();

        }
        return null;
    }

    @Override
    protected void onPostExecute(Object o) {
        super.onPostExecute(o);
        Log.d(TAG, "onPostExecute...");

    }

    // HTTP Request
    void getWeatherJSON() throws IOException {

        // Create URL
        URL url = new URL(urlString);

        // Create connection
        HttpURLConnection httpConnection = (HttpURLConnection) url.openConnection();

        InputStream responseBody = null;
        if (httpConnection.getResponseCode() == 200) {
            responseBody = httpConnection.getInputStream();
            InputStreamReader responseBodyReader = new InputStreamReader(responseBody, "UTF-8");

            // Parsing JSON Responses
            JsonReader jsonReader = new JsonReader(responseBodyReader);

            jsonReader.beginObject(); // Start processing the JSON object
            while (jsonReader.hasNext()) { // Loop through all keys
                String key = jsonReader.nextName(); // Fetch the next key
                if (key.equals("nombre")) { // Check if desired key
                    // Fetch the value as a String
                    String value = jsonReader.nextString();

                    // Do something with the value
                    Log.d(TAG, "******************************************************nombre encontrado");
                    Log.d(TAG, value);
                    this.weather = value;
                    TextView weatherView = (TextView) context.findViewById(R.id.weather);
                    weatherView.setText(weather);

                } else if (key.equals("icono")) { // Check if desired key
                    // Fetch the value as a String
                    String value = jsonReader.nextString();
                    // Do something with the value
                    Log.d(TAG, "******************************************************Icon found");
                    this.icon = value;
                    //ICONO
                    Log.d(TAG , value);

                   ImageView imageView = (ImageView) context.findViewById(R.id.icono);

                    Resources res = context.getResources();
                    int resID = res.getIdentifier(icon , "drawable", context.getPackageName());
                    imageView.setImageResource(resID);



                } else if (key.equals("temperatura")) { // Check if desired key
                    // Fetch the value as a String
                    String value = jsonReader.nextString();

                    // Do something with the value
                    Log.d(TAG, "******************************************************Temperature found");
                    this.temperature = value;
                    Log.d(TAG, value);
                    TextView temperatureView = (TextView) context.findViewById(R.id.temperature);
                    temperatureView.setText(temperature);

                } else {
                    jsonReader.skipValue(); // Skip values of other keys
                }

            }

            jsonReader.close();


        } else {
            Log.d(TAG, "HTTP connection failed");
        }

        httpConnection.disconnect();
    }





}
